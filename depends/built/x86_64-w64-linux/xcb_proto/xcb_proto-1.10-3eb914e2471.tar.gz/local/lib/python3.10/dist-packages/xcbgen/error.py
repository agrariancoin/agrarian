class ResolveException(Exception):
    '''
    Gets thrown when a type doesn't resolve in the XML.
    '''
    pass
